"""
URL patterns for MQTT plugin.
"""

app_name = 'mqtt_plugin'

# No URL patterns - only customization functionality remains
# Dashboard functionality has been removed
urlpatterns = []
