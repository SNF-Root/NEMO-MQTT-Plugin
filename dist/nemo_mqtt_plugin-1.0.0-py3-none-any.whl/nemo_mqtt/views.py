"""
Views for MQTT plugin.
"""
# This file is kept for potential future view additions
# All dashboard functionality has been removed - only customization remains
